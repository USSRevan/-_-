import enum

class Command(enum.Enum):
    none = 0
    order_ch = 1
    order_save = 2
    launch = 3
    pause = 4
    order_break = 5
    
    
    